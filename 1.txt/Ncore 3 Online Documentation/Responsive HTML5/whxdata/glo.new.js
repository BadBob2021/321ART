(function() {
var glossary =  {"type":"glossary","chunkinfos":[{"type":"chunkinfo","first":"Active State","last":"Session","num":"80","node":"gdata1"},{"type":"chunkinfo","first":"SF","last":"Write Transaction Table","num":"18","node":"gdata2"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();