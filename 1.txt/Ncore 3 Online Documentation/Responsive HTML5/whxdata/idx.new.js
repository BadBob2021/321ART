(function() {
var index =  {"type":"index","chunkinfos":[{"type":"chunkinfo","first":"Adapters","last":"Horizontal Toolbar icons","num":"73","node":"idata1"},{"type":"chunkinfo","first":"Initiator Groups","last":"Protocol Parameter Descriptions","num":"70","node":"idata2"},{"type":"chunkinfo","first":"QoS Map to Verilog Example","last":"Window Menu","num":"54","node":"idata3"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();