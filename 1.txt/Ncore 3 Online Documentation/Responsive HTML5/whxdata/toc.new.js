(function() {
var toc =  [{"type":"book","name":"Get Started","key":"toc1"},{"type":"book","name":"Integration Guide","key":"toc4"},{"type":"book","name":"User Guide","key":"toc13"},{"type":"book","name":"Reference Guide","key":"toc25"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();