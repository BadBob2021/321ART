(function() {
var toc =  [{"type":"item","name":"Replication","url":"Ncore_3_Online_Documentation/Integration_Guide/Replication/Replication.htm"},{"type":"item","name":"Replication of NCore Units","url":"Ncore_3_Online_Documentation/Integration_Guide/Replication/Replication_of_NCore_Units.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();