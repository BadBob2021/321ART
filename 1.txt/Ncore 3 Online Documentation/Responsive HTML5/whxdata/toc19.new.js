(function() {
var toc =  [{"type":"item","name":"Mapping","url":"Ncore_3_Online_Documentation/User_Guide/Mapping/Mapping.htm"},{"type":"item","name":"Run the Mapping Tool","url":"Ncore_3_Online_Documentation/User_Guide/Mapping/Run_the_Mapping_Tool.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();