(function() {
var toc =  [{"type":"book","name":"Intro","key":"toc26"},{"type":"book","name":"Protocols and Interfaces","key":"toc27"},{"type":"book","name":"System Attributes","key":"toc28"},{"type":"book","name":"Resiliency","key":"toc29"},{"type":"book","name":"SysSoftwareGuide","key":"toc30"},{"type":"book","name":"Appendix","key":"toc31"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();