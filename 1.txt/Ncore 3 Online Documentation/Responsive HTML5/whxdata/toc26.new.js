(function() {
var toc =  [{"type":"item","name":"Intro","url":"Ncore_3_Online_Documentation/Reference_Guide/Intro/Intro.htm"},{"type":"item","name":"Terminology","url":"Ncore_3_Online_Documentation/Reference_Guide/Intro/Terminology.htm"},{"type":"item","name":"System Overview","url":"Ncore_3_Online_Documentation/Reference_Guide/Intro/System_Overview.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();