(function() {
var toc =  [{"type":"item","name":"EmbedMem","url":"Ncore_3_Online_Documentation/Integration_Guide/EmbedMem/EmbedMem.htm"},{"type":"item","name":"Memory Wrapper","url":"Ncore_3_Online_Documentation/Integration_Guide/EmbedMem/Memory_Wrapper.htm"},{"type":"item","name":"DCE Memory Read Operation Assumption","url":"Ncore_3_Online_Documentation/Integration_Guide/EmbedMem/DCE_Memory_Read_Operation_Assumption.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();