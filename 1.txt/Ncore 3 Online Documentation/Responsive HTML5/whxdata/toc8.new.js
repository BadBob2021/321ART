(function() {
var toc =  [{"type":"item","name":"ResiliencyIntegration","url":"Ncore_3_Online_Documentation/Integration_Guide/ResiliencyIntegration/ResiliencyIntegration.htm"},{"type":"item","name":"Overview","url":"Ncore_3_Online_Documentation/Integration_Guide/ResiliencyIntegration/Overview.htm"},{"type":"item","name":"Integrating External Interface Protection","url":"Ncore_3_Online_Documentation/Integration_Guide/ResiliencyIntegration/Integrating_External_Interface_Protection.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();